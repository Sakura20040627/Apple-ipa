import Foundation
import XCTest
@testable import HexPickCore

private func fixtureFiles() throws -> (Manifest, [String: Data]) {
    let root = DataRepository.bundledSeedURL()
    let manifest = try DataParser.manifest(Data(contentsOf: root.appendingPathComponent("latest.json")))
    var files: [String: Data] = [:]
    for name in manifest.files.keys { files[name] = try Data(contentsOf: root.appendingPathComponent(name)) }
    return (manifest, files)
}
private func fixtureHero() throws -> Hero {
    try DataParser.decoder().decode(Hero.self, from: Data(#"{"name":"测试英雄","games":10000,"wins":5000,"win_rate":0.5}"#.utf8))
}
final class ParsingTests: XCTestCase {
    func testActualSnapshotAndChecksums() throws {
        let (manifest, files) = try fixtureFiles()
        for (name, data) in files { try DataRepository.verify(data, digest: XCTUnwrap(manifest.files[name])) }
        let dataset = try DataParser.parse(manifest: manifest, files: files)
        XCTAssertEqual(dataset.heroes.count, 173)
        XCTAssertEqual(dataset.heroes["1"]?.name, "安妮")
        XCTAssertEqual(dataset.combinations["1"]?["1002"]?.games, 2045)
        XCTAssertEqual(dataset.augments["1002"]?.rarity, "gold")
        XCTAssertEqual(dataset.spells["1"]?["4+32"]?.games, 164059)
        XCTAssertEqual(dataset.items["1"]?["3081"]?.items.first?.name, "影焰")
        XCTAssertTrue(dataset.bands.isEmpty)
    }
    func testMissingOptionalFiles() throws {
        let (manifest, files) = try fixtureFiles()
        let trimmed = files.filter { !["hero_spells.json", "hero_augment_items.json"].contains($0.key) }
        let parsed = try DataParser.parse(manifest: manifest, files: trimmed)
        XCTAssertTrue(parsed.spells.isEmpty); XCTAssertTrue(parsed.items.isEmpty)
    }
    func testUnknownFieldsAreAllowedAndInvalidRequiredFieldRejected() throws {
        let hero = try DataParser.decoder().decode(Hero.self, from: Data(#"{"name":"A","games":10,"wins":5,"win_rate":0.5,"future_field":true}"#.utf8))
        XCTAssertEqual(hero.games, 10)
        XCTAssertThrowsError(try DataParser.decoder().decode(Hero.self, from: Data(#"{"name":"A"}"#.utf8)))
        XCTAssertThrowsError(try Stat(games: 2, wins: 3).validate())
    }
    func testCorruptedChecksumRejected() throws {
        let (manifest, files) = try fixtureFiles()
        let digest = try XCTUnwrap(manifest.files["heroes.json"])
        var corrupt = try XCTUnwrap(files["heroes.json"]); corrupt[0] ^= 1
        XCTAssertThrowsError(try DataRepository.verify(corrupt, digest: digest))
    }
    func testTraversalAndUnknownSchemaRejected() throws {
        let root = DataRepository.bundledSeedURL()
        let original = try Data(contentsOf: root.appendingPathComponent("latest.json"))
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: original) as? [String: Any])
        object["path"] = "patches/../../private"
        XCTAssertThrowsError(try DataParser.manifest(JSONSerialization.data(withJSONObject: object)))
        object["path"] = "patches/16.22/normal"; object["schema_version"] = 999
        XCTAssertThrowsError(try DataParser.manifest(JSONSerialization.data(withJSONObject: object)))
    }
}
final class RecommendationTests: XCTestCase {
    func testOneWinDoesNotBeatStableEvidence() throws {
        let results = RecommendationEngine.rank(ids: ["tiny", "stable"], hero: try fixtureHero(), stats: [
            "tiny": .init(games: 1, wins: 1), "stable": .init(games: 10000, wins: 6000)
        ])
        XCTAssertEqual(results.first?.id, "stable")
    }
    func testMissingAndZeroSamplesDoNotInventRate() throws {
        let results = RecommendationEngine.rank(ids: ["absent", "zero"], hero: try fixtureHero(), stats: ["zero": .init(games: 0, wins: 0)])
        XCTAssertTrue(results.allSatisfy { $0.posterior == nil && $0.score == nil && $0.stat == nil })
    }
    func testUsesCurrentHeroPrior() throws {
        let weak = try DataParser.decoder().decode(Hero.self, from: Data(#"{"name":"A","games":100,"wins":40,"win_rate":0.4}"#.utf8))
        let strong = try DataParser.decoder().decode(Hero.self, from: Data(#"{"name":"B","games":100,"wins":60,"win_rate":0.6}"#.utf8))
        let stats: [String: Stat] = ["x": .init(games: 10, wins: 5)]
        let a = RecommendationEngine.rank(ids: ["x"], hero: weak, stats: stats)
        let b = RecommendationEngine.rank(ids: ["x"], hero: strong, stats: stats)
        XCTAssertLessThan(try XCTUnwrap(a.first?.posterior), try XCTUnwrap(b.first?.posterior))
    }
    func testDeterministicTieAndDuplicateRemoval() throws {
        let results = RecommendationEngine.rank(ids: ["b", "a", "a"], hero: try fixtureHero(), stats: [:])
        XCTAssertEqual(results.map(\.id), ["a", "b"])
    }
    func testFuzzyMatchingRejectsUnrelatedText() throws {
        let data = try DataParser.parse(manifest: fixtureFiles().0, files: fixtureFiles().1)
        XCTAssertEqual(NameMatcher.match("尖端发明冢", augments: data.augments).first?.id, "1002")
        XCTAssertEqual(NameMatcher.match(" 尖端发明家！", augments: data.augments).first?.similarity, 1)
        XCTAssertTrue(NameMatcher.match("zzzzzzzzzzzz", augments: data.augments).isEmpty)
    }
}

private actor FixtureTransport: DataTransport {
    enum Mode: Sendable { case unchanged, validUpdate, corrupt, offline }
    private let mode: Mode
    private let manifest: Data
    private let files: [String: Data]
    private(set) var requests: [URL] = []
    init(_ mode: Mode) throws {
        self.mode = mode
        let (m, files) = try fixtureFiles(); self.files = files
        let root = DataRepository.bundledSeedURL()
        let bytes = try Data(contentsOf: root.appendingPathComponent("latest.json"))
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: bytes) as? [String: Any])
        if mode != .unchanged { object["seq"] = m.seq + (mode == .corrupt ? 2 : 1) }
        // Force a real download of one required file while preserving a valid JSON schema.
        if mode == .validUpdate || mode == .corrupt {
            let changed = try XCTUnwrap(files["heroes.json"]) + Data((mode == .corrupt ? "\n\n" : "\n").utf8)
            var digests = try XCTUnwrap(object["files"] as? [String: [String: Any]])
            digests["heroes.json"] = ["sha256": DataRepository.sha256(changed), "size": changed.count]
            object["files"] = digests
        }
        manifest = try JSONSerialization.data(withJSONObject: object)
    }
    func fetch(_ url: URL) async throws -> Data {
        requests.append(url)
        if mode == .offline { throw URLError(.notConnectedToInternet) }
        if url.lastPathComponent == "latest.json" { return manifest }
        guard var bytes = files[url.lastPathComponent] else { throw URLError(.fileDoesNotExist) }
        if url.lastPathComponent == "heroes.json" {
            bytes.append(Data((mode == .corrupt ? "\n\n" : "\n").utf8))
            if mode == .corrupt { bytes[0] ^= 1 }
        }
        return bytes
    }
}
final class RepositoryTests: XCTestCase, @unchecked Sendable {
    func testUnchangedManifestDoesNotDownloadData() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let transport = try FixtureTransport(.unchanged)
        let repo = DataRepository(root: root, transport: transport)
        _ = try await repo.update()
        let requests = await transport.requests
        XCTAssertEqual(requests.count, 1)
    }
    func testValidCommitAndCorruptRollbackAndOffline() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let valid = try FixtureTransport(.validUpdate)
        let repository = DataRepository(root: root, transport: valid)
        let updated = try await repository.update()
        let (seed, _) = try fixtureFiles()
        XCTAssertEqual(updated.manifest.seq, seed.seq + 1)
        let requests = await valid.requests
        XCTAssertEqual(requests.count, 2, "Unchanged file digests must be reused")
        let pointerBefore = try Data(contentsOf: root.appendingPathComponent("current.json"))
        let bad = DataRepository(root: root, transport: try FixtureTransport(.corrupt))
        do { _ = try await bad.update(); XCTFail("Corrupt update should fail") } catch { }
        let fallback = try await bad.cached()
        XCTAssertEqual(fallback.manifest.seq, updated.manifest.seq)
        let offline = DataRepository(root: root, transport: try FixtureTransport(.offline))
        do { _ = try await offline.update(); XCTFail("Offline update should fail") } catch { }
        let retained = try await offline.cached()
        XCTAssertEqual(retained.manifest.seq, updated.manifest.seq)
        XCTAssertEqual(try Data(contentsOf: root.appendingPathComponent("current.json")), pointerBefore)
    }
}
