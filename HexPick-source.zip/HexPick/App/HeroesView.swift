import SwiftUI
import HexPickCore

enum HeroSort: String, CaseIterable {
    case strength = "强度", name = "名称", win = "胜率", pick = "使用率"
}
struct HeroesView: View {
    @Environment(AppStore.self) private var store
    @State private var search = ""
    @State private var sort: HeroSort = .strength
    @State private var favoritesOnly = false
    private var ids: [String] {
        let filtered = store.heroes.keys.filter { id in
            guard let hero = store.heroes[id] else { return false }
            return (!favoritesOnly || store.favoriteHeroes.contains(id)) &&
                (search.isEmpty || hero.name.localizedStandardContains(search) || (hero.title?.localizedStandardContains(search) ?? false))
        }
        return filtered.sorted {
            guard let a = store.heroes[$0], let b = store.heroes[$1] else { return $0 < $1 }
            switch sort {
            case .strength: return a.rank == b.rank ? $0 < $1 : (a.rank ?? Int.max) < (b.rank ?? Int.max)
            case .name: return a.name == b.name ? $0 < $1 : a.name.localizedStandardCompare(b.name) == .orderedAscending
            case .win: return a.winRate == b.winRate ? $0 < $1 : a.winRate > b.winRate
            case .pick: return a.pickRate == b.pickRate ? $0 < $1 : (a.pickRate ?? 0) > (b.pickRate ?? 0)
            }
        }
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("选好英雄，再选海克斯。").font(.title2.weight(.semibold))
                    if let data = store.dataset {
                        Text("\(data.manifest.patch) · \(data.manifest.modeLabel ?? "常规") · 数据截至")
                        Text(data.manifest.snapshotAt).textSelection(.enabled)
                    }
                    Text(store.status)
                    if let error = store.error { Text(error).foregroundStyle(.orange) }
                }.font(.caption).foregroundStyle(.secondary)
                BandPicker()
                if !store.recent.isEmpty && search.isEmpty && !favoritesOnly {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("最近查看").font(.headline)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 18) {
                                ForEach(store.recent.filter { store.heroes[$0] != nil }, id: \.self) { id in
                                    NavigationLink { HeroDetailView(heroID: id) } label: {
                                        VStack { HeroPortrait(id: id, name: store.heroes[id]?.name ?? "", size: 52)
                                            Text(store.heroes[id]?.name ?? "").font(.caption).lineLimit(1) }
                                    }.buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
                HStack {
                    Text(favoritesOnly ? "收藏英雄" : "全部英雄").font(.headline)
                    Spacer()
                    Picker("排序", selection: $sort) { ForEach(HeroSort.allCases, id: \.self) { Text($0.rawValue).tag($0) } }
                        .pickerStyle(.menu)
                }
                if ids.isEmpty { ContentUnavailableView.search(text: search) }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 96), spacing: 14)], spacing: 24) {
                    ForEach(ids, id: \.self) { id in
                        if let hero = store.heroes[id] {
                            NavigationLink { HeroDetailView(heroID: id) } label: {
                                VStack(spacing: 7) {
                                    HeroPortrait(id: id, name: hero.name)
                                        .overlay(alignment: .topTrailing) {
                                            if store.favoriteHeroes.contains(id) { Image(systemName: "star.fill").font(.caption).padding(3).background(.ultraThinMaterial, in: Circle()) }
                                        }
                                    Text(hero.name).font(.subheadline.weight(.medium)).lineLimit(1)
                                    Text(percent(hero.winRate)).font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                                    Text(hero.rank.map { "#\($0)" } ?? "—").font(.caption2).foregroundStyle(.tertiary)
                                }.frame(maxWidth: .infinity)
                            }.buttonStyle(.plain)
                                .contextMenu { Button(store.favoriteHeroes.contains(id) ? "取消收藏" : "收藏", systemImage: "star") { store.toggleHero(id) } }
                        }
                    }
                }
                Text("强度排序沿用数据源胜率排名，不额外编造强度分数。使用率指全部英雄出场中的占比。")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(20)
        }
        .navigationTitle("海克斯大乱斗")
        .searchable(text: $search, prompt: "搜索英雄名称或称号")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(favoritesOnly ? "显示全部" : "显示收藏", systemImage: favoritesOnly ? "star.fill" : "star") { favoritesOnly.toggle() }
            }
        }
        .refreshable { await store.update() }
    }
}
struct HeroDetailView: View {
    @Environment(AppStore.self) private var store
    let heroID: String
    @State private var rarity = ""
    private var hero: Hero? { store.heroes[heroID] }
    private var results: [Recommendation] {
        store.recommendations(heroID: heroID).filter { rarity.isEmpty || store.augments[$0.id]?.rarity == rarity }
    }
    var body: some View {
        ScrollView {
            if let hero {
                VStack(alignment: .leading, spacing: 24) {
                    HStack(spacing: 16) {
                        HeroPortrait(id: heroID, name: hero.name, size: 80)
                        VStack(alignment: .leading, spacing: 6) {
                            Text(hero.name).font(.title.bold())
                            Text(hero.title ?? "").foregroundStyle(.secondary)
                        }
                    }
                    HStack {
                        StatLabel(title: "英雄胜率", value: percent(hero.winRate))
                        StatLabel(title: "出场次数", value: hero.games.formatted())
                        StatLabel(title: "胜率排名", value: hero.rank.map { "#\($0)" } ?? "—")
                    }
                    NavigationLink { CompareView(initialHeroID: heroID) } label: {
                        Label("开始三选一", systemImage: "rectangle.stack").font(.headline).padding(14).frame(maxWidth: .infinity)
                    }.buttonStyle(.plain).glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: 20))
                    BandPicker()
                    Text("推荐海克斯").font(.title2.bold())
                    RarityPicker(value: $rarity)
                    Text("按保守评分排序 · 英雄基准先验 300 局").font(.caption).foregroundStyle(.secondary)
                    if results.isEmpty { Text("当前筛选暂无足够数据").foregroundStyle(.secondary) }
                    LazyVStack(spacing: 14) {
                        ForEach(results) { result in
                            NavigationLink { AugmentDetailView(augmentID: result.id) } label: { RecommendationCard(result: result) }.buttonStyle(.plain)
                        }
                    }
                    equipment
                    spells
                    Text(statisticalNotice).font(.footnote).foregroundStyle(.secondary)
                }.padding(20)
            } else { ContentUnavailableView("英雄暂无数据", systemImage: "person.crop.circle.badge.questionmark") }
        }
        .navigationTitle(hero?.name ?? "英雄攻略").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("收藏英雄", systemImage: store.favoriteHeroes.contains(heroID) ? "star.fill" : "star") { store.toggleHero(heroID) }
            }
        }
        .onAppear { store.viewed(heroID) }
    }
    @ViewBuilder private var equipment: some View {
        if let table = store.dataset?.items[heroID], !table.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                Text("装备参考 · 全体样本").font(.title2.bold())
                Text("仅适用于下列海克斯的持有者。第一条装备记录为代理，不证明实际绑定目标，不是通用出装顺序。")
                    .font(.caption).foregroundStyle(.secondary)
                ForEach(table.keys.sorted(), id: \.self) { id in
                    if let reference = table[id] {
                        Text(store.augments[id]?.name ?? "海克斯 \(id)").font(.headline)
                        ForEach(reference.items.indices, id: \.self) { i in
                            let item = reference.items[i]
                            HStack {
                                Text(item.name); Spacer()
                                if reference.showWinrate == true { Text(percent(item.games > 0 ? Double(item.wins) / Double(item.games) : nil)).monospacedDigit() }
                                if reference.showSampleSize == true { Text("\(item.games) 局").foregroundStyle(.secondary) }
                            }.font(.subheadline)
                        }
                        if let note = reference.note { Text("数据源注：\(note)").font(.caption).foregroundStyle(.secondary) }
                    }
                }
            }
        }
    }
    @ViewBuilder private var spells: some View {
        if let table = store.dataset?.spells[heroID], !table.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                Text("召唤师技能 · 全体样本").font(.title2.bold())
                Text("按使用次数列出前三组，非技能选择的因果效果。").font(.caption).foregroundStyle(.secondary)
                ForEach(table.keys.sorted { (table[$0]?.games ?? 0) > (table[$1]?.games ?? 0) }.prefix(3), id: \.self) { key in
                    if let stat = table[key] {
                        HStack { Text(spellNames(key)); Spacer(); VStack(alignment: .trailing) {
                            Text(percent(stat.rate)); Text("\(stat.games.formatted()) 局").font(.caption).foregroundStyle(.secondary)
                        } }.monospacedDigit()
                    }
                }
            }
        }
    }
    private func spellNames(_ combo: String) -> String {
        let names = ["1": "净化", "4": "闪现", "6": "幽灵疾步", "7": "治疗术", "13": "清晰术", "14": "引燃", "21": "屏障", "32": "标记"]
        return combo.split(separator: "+").map { names[String($0)] ?? "技能 \($0)" }.joined(separator: " + ")
    }
}
