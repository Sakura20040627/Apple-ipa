import SwiftUI
import HexPickCore

let statisticalNotice = "相关胜率不等于选择该海克斯必然导致胜利。统计来自部分对局结束时的持有记录，不代表全服或因果效果。"
let bandNames = ["casual": "娱乐", "mid": "中分", "high": "高分", "top": "顶尖"]
func percent(_ value: Double?) -> String { value.map { String(format: "%.2f%%", $0 * 100) } ?? "—" }
func signedPP(_ value: Double?) -> String { value.map { String(format: "%+.2f 个百分点", $0 * 100) } ?? "—" }

struct HeroPortrait: View {
    let id: String
    let name: String
    var size: CGFloat = 64
    var body: some View {
        Group {
            if let image = UIImage(named: "hero_\(id)") {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                ZStack { Color.secondary.opacity(0.15); Text(String(name.prefix(1))).font(.title2.bold()) }
            }
        }.frame(width: size, height: size).clipShape(RoundedRectangle(cornerRadius: size * 0.24))
            .accessibilityLabel(name)
    }
}
struct AugmentGlyph: View {
    let rarity: String
    var size: CGFloat = 42
    var color: Color {
        switch rarity { case "gold": return .yellow.opacity(0.75); case "prismatic": return .purple.opacity(0.7); default: return .secondary }
    }
    var body: some View {
        Image(systemName: rarity == "prismatic" ? "diamond" : "hexagon")
            .font(.system(size: size * 0.48, weight: .medium))
            .foregroundStyle(color).frame(width: size, height: size)
            .background(color.opacity(0.09), in: RoundedRectangle(cornerRadius: 12))
            .accessibilityHidden(true)
    }
}
struct StatLabel: View {
    let title: String
    let value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(value).font(.title3.weight(.semibold)).monospacedDigit()
            Text(title).font(.caption).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct RarityPicker: View {
    @Binding var value: String
    var body: some View {
        Picker("稀有度", selection: $value) {
            Text("全部").tag(""); Text("白银").tag("silver")
            Text("黄金").tag("gold"); Text("棱彩").tag("prismatic")
        }.pickerStyle(.segmented)
    }
}
struct BandPicker: View {
    @Environment(AppStore.self) private var store
    var body: some View {
        @Bindable var store = store
        if let data = store.dataset, !data.bands.isEmpty {
            Picker("统计分数段（非官方段位）", selection: $store.band) {
                Text("全体").tag("")
                ForEach(["casual", "mid", "high", "top"].filter { data.bands[$0] != nil }, id: \.self) { key in
                    Text(bandNames[key] ?? key).tag(key)
                }
            }
        }
    }
}
struct RecommendationCard: View {
    @Environment(AppStore.self) private var store
    let result: Recommendation
    var position: Int? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                AugmentGlyph(rarity: store.augments[result.id]?.rarity ?? "")
                VStack(alignment: .leading, spacing: 3) {
                    Text(store.augments[result.id]?.name ?? "海克斯 \(result.id)").font(.headline)
                    Text(store.augments[result.id]?.rarityLabel ?? "未知稀有度").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                if let position { Text(result.score == nil ? "待补充" : (position == 1 ? "优先参考" : "#\(position)"))
                    .font(.caption.weight(.semibold)).padding(8).glassEffect() }
            }
            if let stat = result.stat {
                HStack(alignment: .top) {
                    StatLabel(title: "组合胜率", value: percent(stat.rate))
                    StatLabel(title: "样本局数", value: stat.games.formatted())
                    StatLabel(title: "平滑胜率", value: percent(result.posterior))
                }
                Text("相对英雄基准 \(signedPP(result.delta)) · 保守评分 \(percent(result.score))")
                    .font(.caption).foregroundStyle(.secondary)
                if stat.uncertain { Label("样本量不足，谨慎参考", systemImage: "exclamationmark.triangle").font(.caption).foregroundStyle(.orange) }
            } else { Text("暂无足够数据").foregroundStyle(.secondary) }
            Text(result.reason).font(.footnote).foregroundStyle(.secondary)
        }
        .padding(16).frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).strokeBorder(Color.primary.opacity(position == 1 ? 0.25 : 0.06)))
    }
}
struct RootView: View {
    @Environment(AppStore.self) private var store
    var body: some View {
        TabView {
            Tab("英雄", systemImage: "square.grid.2x2") { NavigationStack { HeroesView() } }
            Tab("三选一", systemImage: "rectangle.stack") { NavigationStack { CompareView() } }
            Tab("图鉴", systemImage: "hexagon") { NavigationStack { AugmentLibraryView() } }
            Tab("设置", systemImage: "gearshape") { NavigationStack { SettingsView() } }
        }.tint(.primary)
            .overlay {
                if store.dataset == nil {
                    ContentUnavailableView {
                        Label("载入攻略数据", systemImage: "arrow.down.circle")
                    } description: { Text(store.error ?? store.status) } actions: { Button("重试") { Task { await store.update() } } }
                    .background(.background)
                }
            }
    }
}
