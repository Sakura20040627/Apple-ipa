import Foundation

public struct Recommendation: Identifiable, Sendable {
    public let id: String
    public let stat: Stat?
    public let posterior: Double?
    public let score: Double?
    public let delta: Double?
    public var reason: String {
        guard let stat, stat.games > 0 else { return "暂无足够数据，不参与胜率比较" }
        if stat.uncertain { return "小样本风险：已向英雄基准平滑，并扣除不确定性" }
        return "基于当前英雄组合统计，综合平滑胜率与样本稳定性"
    }
}
public enum RecommendationEngine {
    public static let priorStrength = 300.0
    /// Beta prior centered on this hero. Rank by posterior mean minus 1.645 posterior SD.
    /// A conservative heuristic, not a causal uplift estimate or formal credible quantile.
    public static func rank(ids: [String], hero: Hero, stats: [String: Stat]) -> [Recommendation] {
        let baseline = min(0.999, max(0.001, hero.winRate))
        return Array(Set(ids)).map { id in
            guard let s = stats[id], s.games > 0, s.wins >= 0, s.wins <= s.games else {
                return Recommendation(id: id, stat: nil, posterior: nil, score: nil, delta: nil)
            }
            let a = Double(s.wins) + baseline * priorStrength
            let b = Double(s.games - s.wins) + (1 - baseline) * priorStrength
            let mean = a / (a + b)
            let sd = sqrt(a * b / ((a + b) * (a + b) * (a + b + 1)))
            return Recommendation(id: id, stat: s, posterior: mean,
                                  score: max(0, mean - 1.645 * sd), delta: mean - baseline)
        }.sorted {
            if $0.score != $1.score { return ($0.score ?? -1) > ($1.score ?? -1) }
            return $0.id < $1.id
        }
    }
}
public struct NameMatch: Sendable, Identifiable {
    public let id: String
    public let similarity: Double
}
public enum NameMatcher {
    public static func normalize(_ text: String) -> String {
        text.folding(options: [.widthInsensitive, .caseInsensitive], locale: Locale(identifier: "zh_CN"))
            .filter { $0.isLetter || $0.isNumber }
    }
    public static func match(_ text: String, augments: [String: Augment], limit: Int = 3) -> [NameMatch] {
        let source = normalize(text)
        guard source.count >= 2 else { return [] }
        return augments.map { id, augment in
            let target = normalize(augment.name)
            let distance = editDistance(Array(source), Array(target))
            let similarity = 1 - Double(distance) / Double(max(source.count, target.count, 1))
            return NameMatch(id: id, similarity: similarity)
        }.filter { $0.similarity >= 0.55 }.sorted {
            $0.similarity == $1.similarity ? $0.id < $1.id : $0.similarity > $1.similarity
        }.prefix(max(0, limit)).map { $0 }
    }
    private static func editDistance(_ a: [Character], _ b: [Character]) -> Int {
        var previous = Array(0...b.count)
        for (i, x) in a.enumerated() {
            var row = [i + 1] + Array(repeating: 0, count: b.count)
            for (j, y) in b.enumerated() {
                row[j + 1] = min(row[j] + 1, previous[j + 1] + 1, previous[j] + (x == y ? 0 : 1))
            }
            previous = row
        }
        return previous[b.count]
    }
}
