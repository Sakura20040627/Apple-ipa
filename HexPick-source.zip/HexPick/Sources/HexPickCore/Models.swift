import Foundation

public enum DataError: Error, LocalizedError, Sendable {
    case invalid(String)
    public var errorDescription: String? {
        switch self { case .invalid(let text): return text }
    }
}
public struct FileDigest: Codable, Sendable, Equatable {
    public let sha256: String
    public let size: Int
}
public struct Manifest: Codable, Sendable, Equatable {
    public let schemaVersion: Int
    public let seq: Int
    public let path: String
    public let patch: String
    public let snapshotAt: String
    public let bands: Bool?
    public let files: [String: FileDigest]
    public let mode: String
    public let modeLabel: String?
    public func validate() throws {
        guard schemaVersion == 1, mode == "normal", seq >= 0,
              path.hasPrefix("patches/"), !path.contains(".."),
              path.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || "/-._".contains($0)) })
        else { throw DataError.invalid("不支持的数据版本或路径") }
        for name in ["heroes.json", "augments.json", "hero_augments.json", "meta.json"] {
            guard files[name] != nil else { throw DataError.invalid("清单缺少 \(name)") }
        }
        for (name, digest) in files {
            guard !name.contains(".."), !name.hasPrefix("/"), !name.contains(":"),
                  digest.sha256.count == 64, digest.sha256.allSatisfy({ $0.isHexDigit }),
                  digest.size > 0, digest.size < 100_000_000
            else { throw DataError.invalid("无效的校验清单") }
        }
    }
}
public struct Hero: Codable, Sendable {
    public let name: String
    public let title: String?
    public let games: Int
    public let wins: Int
    public let winRate: Double
    public let pickRate: Double?
    public let rank: Int?
}
public struct Augment: Codable, Sendable {
    public let name: String
    public let rarity: String
    public var rarityLabel: String {
        switch rarity { case "silver": return "白银"; case "gold": return "黄金"; case "prismatic": return "棱彩"; default: return "未知" }
    }
}
public struct Stat: Codable, Sendable, Equatable {
    public let games: Int
    public let wins: Int
    public let winRate: Double?
    public let lowSample: Bool?
    public init(games: Int, wins: Int, winRate: Double? = nil, lowSample: Bool? = nil) {
        self.games = games; self.wins = wins; self.winRate = winRate; self.lowSample = lowSample
    }
    public var rate: Double? { games > 0 ? Double(wins) / Double(games) : nil }
    public var uncertain: Bool { lowSample == true || games < 3000 }
    public func validate() throws {
        guard games >= 0, wins >= 0, wins <= games,
              winRate.map({ $0.isFinite && (0...1).contains($0) }) ?? true
        else { throw DataError.invalid("统计计数不合法") }
    }
}
public struct ItemReference: Codable, Sendable {
    public struct Item: Codable, Sendable {
        public let item: String
        public let name: String
        public let games: Int
        public let wins: Int
        public let lowSample: Bool?
    }
    public let baseline: Stat?
    public let items: [Item]
    public let note: String?
    public let source: String?
    public let total: Int?
    public let showWinrate: Bool?
    public let showSampleSize: Bool?
}
public struct Metadata: Codable, Sendable {
    public struct Window: Codable, Sendable {
        public let start: String?
        public let endExclusive: String?
        public let timeField: String?
    }
    public let patch: String
    public let snapshotAt: String
    public let limitations: [String]?
    public let notes: [String]?
    public let window: Window?
    public let augmentExposure: String?
    public let modeRule: String?
}
public struct Dataset: Sendable {
    public let manifest: Manifest
    public let heroes: [String: Hero]
    public let augments: [String: Augment]
    public let combinations: [String: [String: Stat]]
    public let spells: [String: [String: Stat]]
    public let items: [String: [String: ItemReference]]
    public let meta: Metadata
    public let bands: [String: Band]
    public struct Band: Sendable {
        public let heroes: [String: Hero]
        public let combinations: [String: [String: Stat]]
    }
    public func heroTable(band: String = "") -> [String: Hero] { bands[band]?.heroes ?? heroes }
    public func comboTable(band: String = "") -> [String: [String: Stat]] { bands[band]?.combinations ?? combinations }
}
public enum DataParser {
    public static func decoder() -> JSONDecoder {
        let decoder = JSONDecoder(); decoder.keyDecodingStrategy = .convertFromSnakeCase; return decoder
    }
    public static func manifest(_ data: Data) throws -> Manifest {
        let m = try decoder().decode(Manifest.self, from: data); try m.validate(); return m
    }
    public static func parse(manifest: Manifest, files: [String: Data]) throws -> Dataset {
        try manifest.validate()
        func read<T: Decodable>(_ name: String, as: T.Type) throws -> T {
            guard let data = files[name] else { throw DataError.invalid("缺少 \(name)") }
            return try decoder().decode(T.self, from: data)
        }
        let heroes = try read("heroes.json", as: [String: Hero].self)
        let augments = try read("augments.json", as: [String: Augment].self)
        let combos = try read("hero_augments.json", as: [String: [String: Stat]].self)
        let meta = try read("meta.json", as: Metadata.self)
        let spells = try files["hero_spells.json"].map { try decoder().decode([String: [String: Stat]].self, from: $0) } ?? [:]
        let items = try files["hero_augment_items.json"].map { try decoder().decode([String: [String: ItemReference]].self, from: $0) } ?? [:]
        try validate(heroes: heroes, combos: combos)
        guard !augments.isEmpty, meta.patch == manifest.patch, meta.snapshotAt == manifest.snapshotAt
        else { throw DataError.invalid("数据与清单不一致") }
        for table in spells.values { for s in table.values { try s.validate() } }
        for table in items.values { for reference in table.values {
            try reference.baseline?.validate()
            for i in reference.items { try Stat(games: i.games, wins: i.wins).validate() }
        } }
        var bands: [String: Dataset.Band] = [:]
        if manifest.bands == true {
            for band in ["casual", "mid", "high", "top"] {
                let hp = "bands/\(band)/heroes.json", cp = "bands/\(band)/hero_augments.json"
                if files[hp] != nil && files[cp] != nil {
                    let h = try read(hp, as: [String: Hero].self), c = try read(cp, as: [String: [String: Stat]].self)
                    try validate(heroes: h, combos: c)
                    bands[band] = .init(heroes: h, combinations: c)
                }
            }
        }
        return Dataset(manifest: manifest, heroes: heroes, augments: augments, combinations: combos,
                       spells: spells, items: items, meta: meta, bands: bands)
    }
    private static func validate(heroes: [String: Hero], combos: [String: [String: Stat]]) throws {
        guard !heroes.isEmpty, !combos.isEmpty else { throw DataError.invalid("空统计表") }
        for h in heroes.values {
            try Stat(games: h.games, wins: h.wins, winRate: h.winRate).validate()
            guard h.pickRate.map({ (0...1).contains($0) }) ?? true else { throw DataError.invalid("使用率不合法") }
        }
        for table in combos.values { for s in table.values { try s.validate() } }
    }
}
