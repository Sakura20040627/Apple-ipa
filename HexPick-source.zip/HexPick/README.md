# HexPick — 海克斯助手

原生 Swift 6 / SwiftUI iPhone 攻略应用，最低 iOS 26，深色默认，使用原生导航、标签页及 Liquid Glass。
无 WebView、无账号登录、无广告与追踪 SDK。iPad 可运行，重点适配 iPhone。

## 交付状态（请先读）

本包包含完整源码、XcodeGen 配置、内置真实数据与头像、单元测试、GitHub Actions。
**交付环境是 Linux，没有 Xcode / iOS SDK，因此未在本环境完成 iOS 编译、模拟器测试或真机测试，也没有伪造 IPA。**
已在 Linux 使用 Swift 6.0.3 编译核心模块并运行 12 项单元测试，全部通过；所有 App Swift 文件通过 Swift 前端语法解析。
这些检查不验证 SwiftUI / Vision API 在 iOS SDK 中的类型检查、界面或设备行为。
下文工作流在 macOS 上执行实际 Swift 测试、iOS 模拟器测试及 Release 编译，成功后生成未签名 IPA。
只有真实构建通过后才能确认 iOS 可构建；工作流定义本身不代表构建已经成功。

## 本地生成与构建

需要 Mac、稳定版 Xcode 26 或更高、iOS 26 SDK 和 XcodeGen。iOS / macOS 使用系统 CryptoKit，没有外部 Swift 库依赖。Linux 核心测试条件性使用 Apple swift-crypto 3.9.0。

```bash
brew install xcodegen
cd HexPick
xcodegen generate
open HexPick.xcodeproj
```

选择 `HexPick` scheme，选择 iOS 26 iPhone 模拟器，运行。
在 Xcode 中 Product → Test 执行 iOS 测试。也可先运行纯数据核心测试：

```bash
swift test
```

物理设备未签名 Release：

```bash
xcodebuild build -project HexPick.xcodeproj -scheme HexPick \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath build/Release \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY=""
mkdir -p build/package/Payload
ditto build/Release/Build/Products/Release-iphoneos/HexPick.app build/package/Payload/HexPick.app
(cd build/package && zip -qry ../HexPick-unsigned.ipa Payload)
```

**未签名 IPA 不能直接安装。** 需用你自己的有效开发者签名及相应描述文件重新签名，
或在 Xcode 的 Signing & Capabilities 选择自己的 Team 后对连接的 iPhone 运行。
无需把 Apple ID、密码、证书私钥或账号凭据发给任何人，本项目和 Actions 都不需要这些信息。

## GitHub Actions 获取 IPA

1. 将压缩包解压后的项目内容放在你自己的 GitHub 仓库根目录，保留隐藏目录 `.github`。
2. 提交到 `main` / `master`，或在 Actions → Build HexPick iOS → Run workflow 手动运行。
3. 工作流在 `macos-15` 中探测已安装的稳定版 Xcode >= 26，避免使用旧默认 Xcode。
4. 依次校验内置数据、执行 Swift 核心测试、生成项目、选择可用的 iOS >=26 模拟器、
   执行 iOS 测试、编译 iPhone Release、打包 `Payload/HexPick.app`。
5. 成功后下载 artifact `HexPick-unsigned-IPA`，解压得到 `HexPick-unsigned.ipa`，再自行重新签名。
6. 失败时查看日志及 `HexPick-test-results`；不会将失败构建包装成可安装产品。

GitHub Runner 预装镜像会变化；缺少合适的 Xcode 或模拟器时会给出明确错误，
不静默降级至低于 iOS 26 的 SDK。无需填写 Secrets。

## 已实现功能

- 英雄中文名/称号搜索、头像网格、胜率、强度（来源胜率排名）、使用率排序、收藏、最近查看。
- 英雄专属海克斯推荐，白银/黄金/棱彩筛选，原始及平滑胜率、样本风险。
- 三选一手动候选选择，去重，三张按保守评分排序的卡片，缺失数据明确标注。
- 相册导入、相机拍屏、Vision 中文 OCR、编辑距离模糊匹配、识别置信度及名称相似度。
  每次截图必须人工逐项确认或手动修改，未确认不会生成本轮推荐。
- 全海克斯图鉴、搜索、稀有度过滤、收藏、总体持有人次统计及高胜率适配英雄。
- 当前数据实际提供时显示装备参考与技能统计；装备参考按英雄+海克斯限定，不假装通用出装。
- 启动检查更新、手动更新、SHA-256、离线快照、失败回退、原子缓存提交、清除缓存。
- 深色/浅色/系统主题，版本/样本窗口，来源授权、统计说明和隐私页。
- 仅当清单和文件确实提供可校验分数段数据时显示相应筛选。分数段不是官方段位。

## 真实数据与更新

来源：https://github.com/czgreat/aramhex-data ，CC BY-NC 4.0，作者 czgreat。
开发前读取了 README.md、AGENTS.md、latest.json、index.json；原文留存于 Documentation。
内置快照以 `Sources/HexPickCore/Seed/latest.json` 为准。运行时不硬编码版本目录。

启动时先在数据 actor 中验证并读取已提交缓存，损坏时使用内置快照，然后请求 `main/latest.json`。
比较清单的 seq、path 和各文件校验信息；完全不变只请求 latest，不下载数据。
变更时使用不可变的 `data-v<seq>` tag 和清单 `path` 下载，避免更新期间混合两个快照。
逐文件检查字节长度和 SHA-256，再解析与检查范围、计数、元数据一致性。
未变化文件复用已验证的缓存。可选文件不存在时不展示相应功能；清单声称存在但下载失败时拒绝整次更新。
缺少必需字段或未知 schema 时拒绝新快照，保留旧数据，不崩溃、不编造默认胜率。

所有文件写入独立 generation 目录后，以 `.atomic` 写入 `current.json` 指针提交；旧数据在提交前保持完整。
下载、哈希、JSON 解析、文件读写和 Vision 识别均在独立 actor 中，避免主线程加载大 JSON。
UI 的 AppStore 在 MainActor 上维护展示状态与用户偏好，采用 Observation / MVVM。

更新依赖来源仓库发布，并非自行采集国服实时对局。数据源停更时保留最近有效快照。
`index.json` 用于开发核对数据目录；此版不提供历史版本切换，正常更新入口是 latest。

## 推荐算法

`RecommendationEngine` 集中实现，可以独立测试。

- 当前英雄胜率为先验均值，先验样本强度 k=300。
- Beta 后验：a = wins + p×300；b = games−wins + (1−p)×300。
- 平滑胜率：a/(a+b)。
- 保守评分：max(0, 平滑胜率 − 1.645 × 后验标准差)。
- 样本不足标记尊重来源 `low_sample`，同时对 games<3000 警示。
- 缺失或零样本不计算胜率/评分；相同分数用 ID 稳定排序。
- 统计适配度为平滑胜率与该英雄胜率之差（百分点），不表示因果提升。

评分是保守排序启发式，不是精确置信下界。相关胜率不等于选了该海克斯必胜。
不统计已有海克斯之间的交互，不根据队伍阵容或玩家熟练度建模；现有公开表不支持这些推断。

## 图片和隐私

英雄头像随包内置，来源清单和校验值见 Documentation/portrait-sources.json。
海克斯使用原创稀有度几何符号，不冒充游戏内图标。更换为游戏图标需先确认合法来源和许可。
统计数据的 CC 许可不覆盖 Riot / 腾讯的图像商标；详见 THIRD_PARTY_NOTICES.md。

相册用 PhotosPicker，不索取全相册权限。相机权限在拍摄时请求；Vision 只在本地处理。
照片不上传、不落入应用缓存。没有 PC 游戏内存读取、跨设备悬浮窗或自动代选。
收藏/最近查看/主题使用本机 UserDefaults；JSON 缓存使用 Application Support。

## 项目目录

- `App/`：SwiftUI、AppStore、Vision、相机桥接、资源。
- `Sources/HexPickCore/`：真实模型、解析、推荐、匹配、更新 actor、内置快照。
- `Tests/HexPickCoreTests/`：解析、校验、推荐、名称匹配、重复下载/失败回退测试。
- `project.yml`：完整 XcodeGen 工程和测试 scheme。
- `.github/workflows/build-ios.yml`：测试、Release、未签名 IPA 构建产物。
- `scripts/validate_snapshot.py`：无需网络校验实际快照和头像。
- `scripts/prepare_assets.py`：可选，重新取得头像；构建无需运行或依赖图片 CDN。
- `Documentation/`：读取过的来源说明、许可证、资源出处与验证记录。

## 测试与实机验收

单元测试使用包内原始快照，覆盖真实嵌套键、可选表、未知字段、坏计数、路径穿越、SHA-256 篡改、
小样本 100% 不压倒大样本、缺数据无虚构、英雄先验差异、确定性排序、OCR 名称模糊匹配、
无变化不重复下载、复用未变文件、成功提交、损坏/断网回退。

待在 Xcode/iPhone 验证的项目：深浅色及动态字体、不同屏幕/横屏、快速滚动、弱网/中断更新、
系统拒绝相机权限、实际 PC 游戏字体/反光照片的 OCR 准确性、照片方向、重签名安装。
OCR 的置信度不是准确率，不能声称已对所有游戏字体或屏幕条件验证。
