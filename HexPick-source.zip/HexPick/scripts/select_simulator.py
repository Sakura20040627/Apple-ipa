#!/usr/bin/env python3
import json, subprocess, re
result=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','available','--json']))
choices=[]
for runtime, devices in result['devices'].items():
    match=re.search(r'iOS-(\d+)-(\d+)',runtime)
    if not match or int(match.group(1))<26: continue
    for device in devices:
        if device.get('isAvailable') and device['name'].startswith('iPhone'):
            choices.append(((int(match.group(1)),int(match.group(2))),device['udid']))
if not choices: raise SystemExit('No available iPhone simulator with iOS >=26')
print('SIMULATOR_ID='+max(choices)[1])
