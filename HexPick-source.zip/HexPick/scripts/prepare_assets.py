#!/usr/bin/env python3
"""Fetch portrait-only game resources. No game stats are obtained from this CDN.
Personal noncommercial fan project; see THIRD_PARTY_NOTICES.md before distributing.
"""
import concurrent.futures, hashlib, json, pathlib, urllib.request, time, subprocess
ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'App/Assets.xcassets'
SEED = ROOT / 'Sources/HexPickCore/Seed'

def fetch(hero_id):
    folder = ASSETS / f'hero_{hero_id}.imageset'
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / 'portrait.png'
    url = f'https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-icons/{hero_id}.png'
    if not target.exists():
        last = None
        for attempt in range(3):
            try:
                data = subprocess.check_output(['curl', '-fLsS', '--max-time', '30', url])
                if not data.startswith(b'\x89PNG\r\n\x1a\n'): raise ValueError('not PNG')
                target.write_bytes(data)
                break
            except Exception as exc:
                last = exc; time.sleep(attempt + 1)
        else: raise RuntimeError(f'{hero_id}: {last}')
    (folder/'Contents.json').write_text(json.dumps({'images':[{'filename':'portrait.png','idiom':'universal'}],'info':{'author':'xcode','version':1}}))
    return {'hero_id':hero_id, 'url':url, 'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}

if __name__ == '__main__':
    ASSETS.mkdir(parents=True, exist_ok=True)
    (ASSETS/'Contents.json').write_text('{"info":{"author":"xcode","version":1}}')
    heroes = json.loads((SEED/'heroes.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
        records = list(pool.map(fetch, heroes))
    (ROOT/'Documentation/portrait-sources.json').write_text(json.dumps(records,indent=2))
    print(f'{len(records)} portraits verified')
