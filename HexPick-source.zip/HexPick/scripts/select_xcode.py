#!/usr/bin/env python3
"""Do not rely on the macOS runner's default Xcode (it may be Xcode 16)."""
import pathlib, re, subprocess
choices=[]
for app in pathlib.Path('/Applications').glob('Xcode*.app'):
    developer = app/'Contents/Developer'
    result = subprocess.run([str(developer/'usr/bin/xcodebuild'), '-version'], capture_output=True, text=True)
    match = re.search(r'Xcode (\d+(?:\.\d+)*)', result.stdout)
    if match and int(match.group(1).split('.')[0]) >= 26 and 'beta' not in app.name.lower():
        choices.append((tuple(int(x) for x in match.group(1).split('.')), developer))
if not choices: raise SystemExit('No stable Xcode >= 26 is installed on this runner')
selected = max(choices, key=lambda item:item[0])[1]
subprocess.run(['sudo','xcode-select','-s',str(selected)],check=True)
print(f'Selected {selected}')
