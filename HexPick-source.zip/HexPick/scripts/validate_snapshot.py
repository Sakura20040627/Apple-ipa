#!/usr/bin/env python3
"""Offline verification of the exact bundled upstream bytes; no simulated game data."""
import hashlib, json, pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
SEED=ROOT/'Sources/HexPickCore/Seed'
m=json.loads((SEED/'latest.json').read_text())
assert m['schema_version']==1 and m['mode']=='normal'
for name, digest in m['files'].items():
    data=(SEED/name).read_bytes()
    assert len(data)==digest['size'], name
    assert hashlib.sha256(data).hexdigest()==digest['sha256'], name
    json.loads(data)
h=json.loads((SEED/'heroes.json').read_text());a=json.loads((SEED/'augments.json').read_text())
c=json.loads((SEED/'hero_augments.json').read_text()); meta=json.loads((SEED/'meta.json').read_text())
assert meta['patch']==m['patch'] and meta['snapshot_at']==m['snapshot_at']
for hero in h.values():
    assert 0 <= hero['wins'] <= hero['games'] and 0 <= hero['win_rate'] <= 1
for hero_id,table in c.items():
    assert hero_id in h
    for augment_id,stat in table.items():
        assert augment_id in a
        assert 0 <= stat['wins'] <= stat['games']
        assert abs(stat['wins']/stat['games']-stat['win_rate'])<0.000001
assert h['1']['name']=='安妮'
assets=ROOT/'App/Assets.xcassets'
missing=[i for i in h if not (assets/f'hero_{i}.imageset/portrait.png').exists()]
assert not missing, f'Missing portraits: {missing}'
for record in json.loads((ROOT/'Documentation/portrait-sources.json').read_text()):
    path=assets/f"hero_{record['hero_id']}.imageset/portrait.png"
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256']
print(f'PASS: snapshot seq={m["seq"]}; {len(h)} heroes, {len(a)} augments, {sum(map(len,c.values()))} combinations; SHA-256 and portrait completeness verified')
